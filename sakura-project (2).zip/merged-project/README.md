# Flash — Flashcard Generator

Merged, working full-stack app: Express + SQLite backend, vanilla-JS
frontend, served from one server on one port.

## Setup

```bash
cp .env.example .env   # fill in JWT_SECRET at minimum
npm install
npm start               # or: npm run dev  (auto-restarts on file changes)
```

Open `http://localhost:5000` — the frontend and API are served from the
same origin, same port.

## Project structure

```
server.js                       app setup, mounts API + static frontend
public/                         frontend (index.html, style.css, app.js)
config/db.js                    SQLite connection + table creation
models/                         User / NoteSet / Flashcard table queries
middleware/                     auth (JWT), upload (multer), error handler
routes/                         /api/auth/*, /api/notesets/*
controllers/                    register/login, upload/list/cards/retry
services/
  textExtraction.js             pdf-parse for PDFs, passes images through
  generateFlashcards.js         Calls Google Gemini (free tier) to turn
                                 notes into flashcards
uploads/                        uploaded files land here (gitignored)
```

## What was wrong when the two zips were merged

The frontend and backend were built to a shared API contract but the
frontend was still a static prototype — it never actually called the
backend. Fixed:

1. **Frontend had zero network calls.** `noteSets` and `deck` were
   hardcoded arrays, the sign-in form just called `preventDefault()`, and
   the upload buttons only touched local state. Rewrote `public/app.js` to
   call the real API: register/login, list note sets, upload, poll for
   status, fetch cards, retry.
2. **No auth/session handling.** Nothing stored the JWT or attached it to
   requests. Added a JWT stored in `localStorage`, an `Authorization:
   Bearer` header on every API call, a router guard that redirects to
   `#/signin` when logged out, and a sign-out flow.
3. **Register needs a `name`, the sign-in form didn't have one.** The
   sign-in form now shows a Name field in register mode.
4. **CORS/port mismatch.** Backend was locked to
   `cors({ origin: 'http://localhost:3000' })` with no static file serving
   at all, so there was no way to actually load the frontend at that
   origin. `server.js` now serves `public/` itself — everything is
   same-origin on `:5000`, so cross-origin requests aren't needed for
   normal use (`ALLOWED_ORIGIN` env var is still there if you ever split
   them again).
5. **"Retry generation" button had no backend route.** `POST
   /api/notesets` and `GET /api/notesets` existed, but nothing to retry a
   failed set. Added `POST /api/notesets/:id/retry`, which re-runs the
   extract → generate pipeline against the file already on disk, and a
   `Flashcard.deleteByNoteSetId` so retried cards replace the old ones
   instead of duplicating.
6. **Upload scope mismatch.** The UI lets you attach one PDF *and* up to
   10 images at once, but the backend only accepts a single file per note
   set (`multer.single('file')`, one `filePath` column). This is a real
   product decision, not something to silently paper over — for now the
   frontend picks one file per set (PDF takes priority, otherwise the
   first image) and shows an inline note when you've attached more than
   it can use. If you want true multi-image note sets, that needs a
   backend change (e.g. `multer.array()` + concatenating extracted text
   per note set) — flagging it rather than guessing at the intended
   behavior.
7. **Study view was always the same 3 hardcoded flashcards** regardless of
   which set you clicked. Now fetches `GET /api/notesets/:id/cards` for
   the selected set and handles the `processing`/`failed` states.

## Notes / decisions carried over from the original backend

- **SQLite via Node's built-in `node:sqlite`** (not `better-sqlite3`).
  Requires Node 22.5+ (24 works fine); prints an "experimental feature"
  warning on startup — expected and harmless.
- **bcryptjs instead of bcrypt** — pure JS, no native build step.
- **Upload response timing.** `POST /api/notesets` (and now
  `POST /api/notesets/:id/retry`) respond immediately with
  `{ noteSetId, status: "processing" }`, then keep working in the
  background on the same request handler. Poll `GET /api/notesets` or
  `GET /api/notesets/:id/cards` to see status flip to `ready`/`failed`
  — the frontend already does this.
- **Flashcard generation calls Google Gemini's free tier**
  (`services/generateFlashcards.js`) — text notes go straight to the
  model as a prompt; images (no OCR step — see below) are base64-encoded
  and sent as an inline image part in the same request. Get a free key at
  [aistudio.google.com/apikey](https://aistudio.google.com/apikey) (no
  credit card required) and put it in `.env` as `LLM_API_KEY`. Without a
  key set, uploads fail cleanly at the generation step and the note set's
  status flips to `"failed"` — check the server log for the exact error.
- **Image handling** — `textExtraction.js` intentionally skips OCR for
  images and returns `null`; `generateFlashcards.js` picks that up and
  sends the image file itself to Gemini's vision input instead of text.

## Known follow-ups (not fixed, flagged instead)

- `multer@1.x` and `uuid@9` print deprecation warnings on `npm install`
  (pre-existing dependency choices, not part of this merge) — worth
  bumping to `multer@2.x` when you have time to retest the upload path.
- Multi-file note sets (see point 6 above) need a real backend decision
  before they can work end to end.

## Quick manual test

```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Ada","email":"ada@example.com","password":"hunter2"}'

# Upload a note set (replace TOKEN with the token from above)
curl -X POST http://localhost:5000/api/notesets \
  -H "Authorization: Bearer TOKEN" \
  -F "title=Bio Chapter 3" \
  -F "file=@/path/to/some.pdf"

# List note sets
curl http://localhost:5000/api/notesets -H "Authorization: Bearer TOKEN"

# Get cards (poll until status is "ready")
curl http://localhost:5000/api/notesets/NOTESET_ID/cards -H "Authorization: Bearer TOKEN"

# Retry a failed set
curl -X POST http://localhost:5000/api/notesets/NOTESET_ID/retry -H "Authorization: Bearer TOKEN"
```
